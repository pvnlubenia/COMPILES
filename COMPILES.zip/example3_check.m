% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6
syms A AE B E

% Fluxes
v1 = k1*A*E;
v2 = k2*AE;
v3 = k3*AE;
v4 = k4*B*E;
v5 = k5*B;
v6 = k6;

% ODEs
odeA  = -v1 + v2 + v6;
odeAE = v1 - v2 - v3 + v4;
odeB  = v3 - v4 - v5;
odeE  = -v1 + v2 + v3 - v4;

% Solution
A  = (k6*(k2*k4 + (k2*k5)/E + (k3*k5)/E))/(k1*k3*k5);
AE = (E*k6*(k4 + k5/E))/(k3*k5);
B  = k6/k5;

% Check
checkA  = simplify(subs(odeA))
checkAE = simplify(subs(odeAE))
checkB  = simplify(subs(odeB))
checkE  = simplify(subs(odeE))