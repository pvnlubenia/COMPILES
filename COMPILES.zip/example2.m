% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 2                                                              %
%                                                                           %
%                                                                           %
% This is Example 18 in Johnston et al (2019): Histidine Kinase Network     %
%                                                                           %
% RESULT: The network has no nontrival independent decomposition. The       %
%    steady state of species X and Xp are parametrized in terms of the rate %
%    constants and the free parameters Y and Yp. There are 2 conservation   %
%    laws.                                                                  %
%                                                                           %
% Reference: Johnston M, Mueller S, Pantea C (2019) A deficiency-based      %
%    approach to parametrizing positive equilibria of biochemical reaction  %
%    systems. Bull Math Biol 81:1143–1172.                                  %
%    https://doi.org/10.1007/s11538-018-00562-0                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2';
model = addReaction(model, 'X->Xp', ...          % just a visual guide on how the reaction looks like
                           {'X'}, {1}, [1], ...  % reactant species, stoichiometry, kinetic order
                           {'Xp'}, {1}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);               % reversible or not
model = addReaction(model, 'Xp+Y<->X+Yp', ...
                           {'Xp', 'Y'}, {1, 1}, [1, 1], ...
                           {'X', 'Yp'}, {1, 1}, [1, 1], ...
                           true);
model = addReaction(model, 'Yp->Y', ...
                           {'Yp'}, {1}, [1], ...
                           {'Y'}, {1}, [ ], ...
                           false);

% Generate the parametrized steady steady solution
[equation, species, free_parameter, conservation_law, model] = steadyState(model);