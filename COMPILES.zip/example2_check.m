% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4
syms X Xp Y Yp

% Fluxes
v1 = k1*X;
v2 = k2*Xp*Y;
v3 = k3*X*Yp;
v4 = k4*Yp;

% ODEs
odeX  = -v1 + v2 - v3;
odeXp = v1 - v2 + v3;
odeY  = -v2 + v3 + v4;
odeYp = v2 - v3 - v4;

% Solution
X  = (Yp*k4)/k1;
Xp = (Yp*k4*(k1 + Yp*k3))/(Y*k1*k2);

% Check
checkX  = simplify(subs(odeX))
checkXp = simplify(subs(odeXp))
checkY  = simplify(subs(odeY))
checkYp = simplify(subs(odeYp))