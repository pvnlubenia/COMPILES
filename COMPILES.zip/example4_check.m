% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5
syms X1 X2 X3 X4 X5

% Fluxes
v1  = k1*X1*X2;
v2  = k2*X3;
v3  = k3*X3;
v4  = k4*X4;
v5  = k5*X4*X5;

% ODEs
ode1 = -v1 + v2;
ode2 = -v1 + v2;
ode3 = v1 - v2 - v3 + v3;
ode4 = v3 - v4 - v5;
ode5 = -v5 + v5;

% Solution
X1 = (X4*k2*(k4 + X5*k5))/(X2*k1*k3);
X3 = (X4*(k4 + X5*k5))/k3;

% Check
check1 = simplify(subs(ode1))
check2 = simplify(subs(ode2))
check3 = simplify(subs(ode3))
check4 = simplify(subs(ode4))
check5 = simplify(subs(ode5))