% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21
syms X1 X2 X3 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13

% Fluxes
v1  = k1*X1*X2;
v2  = k2*X3;
v3  = k3*X3;
v4  = k4*X4;
v5  = k5*X4*X5;
v6  = k6*X5*X6;
v7  = k7*X7;
v8  = k8*X8;
v9  = k9*X9;
v10 = k10*X9;
v11 = k11*X1;
v12 = k12*X5;
v13 = k13*X9;
v14 = k14*X10;
v15 = k15*X7*X9;
v16 = k16*X4*X9;
v17 = k17*X10*X11;
v18 = k18*X12;
v19 = k19*X12;
v20 = k20*X4*X11;
v21 = k21*X13;

% ODEs
ode1  = -v1 + v2 + v9 - v11;
ode2  = -v1 + v2;
ode3  = v1 - v2 - v3 + v3;
ode4  = v3 - v4 - v5 - v16 + v16 - v20 + v21;
ode5  = -v5 + v5 - v6 + v7 - v12 + v19;
ode6  = -v6 + v7;
ode7  = v6 - v7 - v15 + v15;
ode8  = -v8 + v8;
ode9  = v8 - v13 - v15 - v16 - v9 + v9 - v10 + v10;
ode10 = v10 - v14 - v17 + v18;
ode11 = -v17 + v18 + v19 - v20 + v21;
ode12 = v17 - v18 - v19;
ode13 = v20 - v21;

% Solution
X1  = (X9*k9)/k11;
X2  = (X4*k2*k11*(k4 + (X9*X13*k5*k10*k17*k19*k21)/(k12*(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21))))/(X9*k1*k3*k9);
X3  = (X4*(k4 + (X9*X13*k5*k10*k17*k19*k21)/(k12*(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21))))/k3;
X5  = (X9*X13*k10*k17*k19*k21)/(k12*(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21));
X6  = (X7*k7*k12*(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21))/(X9*X13*k6*k10*k17*k19*k21);
X8  = (X9*(k13 + X4*k16 + X7*k15))/k8;
X10 = (X4*X9*k10*k20*(k18 + k19))/(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21);
X11 = (X13*k21)/(X4*k20);
X12 = (X9*X13*k10*k17*k21)/(X4*k14*k18*k20 + X4*k14*k19*k20 + X13*k17*k19*k21);

% Check
check1  = simplify(subs(ode1))
check2  = simplify(subs(ode2))
check3  = simplify(subs(ode3))
check4  = simplify(subs(ode4))
check5  = simplify(subs(ode5))
check6  = simplify(subs(ode6))
check7  = simplify(subs(ode7))
check8  = simplify(subs(ode8))
check9  = simplify(subs(ode9))
check10 = simplify(subs(ode10))
check11 = simplify(subs(ode11))
check12 = simplify(subs(ode12))
check13 = simplify(subs(ode13))