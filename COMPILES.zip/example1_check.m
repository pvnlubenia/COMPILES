% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4
syms A B

% Fluxes
v1 = k1;
v2 = k2;
v3 = k3*A*B;
v4 = k4*B;

% ODEs
odeA = v1 - v3;
odeB = -v3 + v3 + v2 - v4;

% Solution
A = (k1*k4)/(k2*k3);
B = k2/k4;

% Check
checkA = simplify(subs(odeA))
checkB = simplify(subs(odeB))