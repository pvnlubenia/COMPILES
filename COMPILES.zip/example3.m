% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 3                                                              %
%                                                                           %
%                                                                           %
% This is an illustration in Hernandez et al (2022): A reaction network     %
%    with mass action kinetics                                              %
%                                                                           %
% RESULT: The network has no nontrival independent decomposition. The       %
%    steady state of species A, AE, and B are parametrized in terms of the  %
%    rate constants and the free parameter E. There is 1 conservation law.  %
%                                                                           %
% Reference: Hernandez B, Lubenia P, Johnston M, Kim J (2022) Deriving      %
%    analytic positive steady states of chemical reaction systems via       %
%    network decomposition and network translation (in preparation)         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 3';
model = addReaction(model, 'A+E<->AE', ...              % just a visual guide on how the reaction looks like
                           {'A', 'E'}, {1, 1}, [1], ... % reactant species, stoichiometry, kinetic order
                           {'AE'}, {1}, [1], ...        % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                       % reversible or not
model = addReaction(model, 'AE<->B+E', ...
                           {'AE'}, {1}, [1], ...
                           {'B', 'E'}, {1, 1}, [1, 1], ...
                           true);
model = addReaction(model, 'B->0', ...
                           {'B'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           false);
model = addReaction(model, '0->A', ...
                           { }, { }, [ ], ...
                           {'A'}, {1}, [ ], ...
                           false);

% Generate the parametrized steady steady solution
[equation, species, free_parameter, conservation_law, model] = steadyState(model);