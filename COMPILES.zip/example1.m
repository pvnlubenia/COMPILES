% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% A network that does not need a phantom edge                               %
%                                                                           %
% RESULT: The network has 2 subnetworks. The steady state of species A and  %
%    B are parametrized in terms of the rate constants. There are no free   %
%    parameters and conservation laws.                                      %
%                                                                           %
% Reference: None                                                           %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model = addReaction(model, '0->A', ...          % just a visual guide on how the reaction looks like
                           { }, { }, [ ], ...   % reactant species, stoichiometry, kinetic order
                           {'A'}, {1}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);              % reversible or not
model = addReaction(model, '0->B', ...
                           { }, { }, [ ], ...
                           {'B'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'A+B->B', ...
                           {'A', 'B'}, {1, 1}, [1, 1], ...
                           {'B'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'B->0', ...
                           {'B'}, {1}, [ ], ...
                           { }, { }, [ ], ...
                           false);

% Generate the parametrized steady steady solution
[equation, species, free_parameter, conservation_law, model] = steadyState(model);