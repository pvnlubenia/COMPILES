% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21 k22
syms X1 X2 X3 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13

% Fluxes
v1  = k1*X1;
v2  = k2*X3;
v3  = k3*X2*X7;
v4  = k4*X6;
v5  = k5*X5*X7;
v6  = k6*X4;
v7  = k7*X3*X6;
v8  = k8*X8;
v9  = k9*X1*X4;
v10 = k10*X9;
v11 = k11*X2;
v12 = k12*X5;
v13 = k13*X7;
v14 = k14;
v15 = k15*X6*X8;
v16 = k16*X10;
v17 = k17*X7*X9;
v18 = k18*X11;
v19 = k19*X6*X9;
v20 = k20*X12;
v21 = k21*X7*X8;
v22 = k22*X13;

% ODEs
ode1  = -v1 + v1 - v9 + v10;
ode2  = v1 - v11 - v3 + v4;
ode3  = -v2 + v2 - v7 + v8;
ode4  = v5 - v6 - v9 + v10;
ode5  = v2 - v12 - v5 + v6;
ode6  = v3 - v4 - v7 + v8 - v15 + v16 - v19 + v20;
ode7  = -v3 + v4 - v5 + v6 - v13 + v14 - v17 + v18 - v21 + v22;
ode8  = v7 - v8 - v15 + v16 - v21 + v22;
ode9  = v9 - v10 - v17 + v18 - v19 + v20;
ode10 = v15 - v16;
ode11 = v17 - v18;
ode12 = v19 - v20;
ode13 = v21 - v22;

% Solution
X1  = (X6*k4*k11*k13)/(k1*k3*k14);
X2  = (X6*k4*k13)/(k3*k14);
X3  = (X8*k8)/(X6*k7);
X4  = (X8*k2*k5*k8*k14)/(X6*k6*k7*k12*k13);
X5  = (X8*k2*k8)/(X6*k7*k12);
X7  = k14/k13;
X9  = (X8*k2*k4*k5*k8*k9*k11)/(k1*k3*k6*k7*k10*k12);
X10 = (X6*X8*k15)/k16;
X11 = (X8*k2*k4*k5*k8*k9*k11*k14*k17)/(k1*k3*k6*k7*k10*k12*k13*k18);
X12 = (X6*X8*k2*k4*k5*k8*k9*k11*k19)/(k1*k3*k6*k7*k10*k12*k20);
X13 = (X8*k14*k21)/(k13*k22);

% Check
check1  = simplify(subs(ode1))
check2  = simplify(subs(ode2))
check3  = simplify(subs(ode3))
check4  = simplify(subs(ode4))
check5  = simplify(subs(ode5))
check6  = simplify(subs(ode6))
check7  = simplify(subs(ode7))
check8  = simplify(subs(ode8))
check9  = simplify(subs(ode9))
check10 = simplify(subs(ode10))
check11 = simplify(subs(ode11))
check12 = simplify(subs(ode12))
check13 = simplify(subs(ode13))