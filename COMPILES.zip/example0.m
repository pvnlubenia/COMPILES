% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 0                                                              %
%                                                                           %
%                                                                           %
% This is an illustration in Hernandez et al (2022): A reaction network     %
%    with mass action kinetics                                              %
%                                                                           %
% RESULT: The network has 2 subnetworks. The steady state of species A, B,  %
%    C, and D are parametrized in terms of the rate constants and sigma.    %
%    There are no free parameters and 1 conservation law.                   %
%                                                                           %
% Reference: Hernandez B, Lubenia P, Johnston M, Kim J (2022) Deriving      %
%    analytic positive steady states of chemical reaction systems via       %
%    network decomposition and network translation (in preparation)         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 0';
model = addReaction(model, 'A+C->0', ...                   % just a visual guide on how the reaction looks like
                           {'A', 'C'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           { }, { }, [ ], ...              % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                         % reversible or not
model = addReaction(model, '0->A', ...
                           { }, { }, [ ], ...
                           {'A'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'A->A+C', ...
                           {'A'}, {1}, [1], ...
                           {'A', 'C'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'B+C->B', ...
                           {'B', 'C'}, {1, 1}, [1, 1], ...
                           {'B'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'B<->D', ...
                           {'B'}, {1}, [1], ...
                           {'D'}, {1}, [1], ...
                           true);

% Generate the parametrized steady steady solution
[equation, species, free_parameter, conservation_law, model] = steadyState(model);