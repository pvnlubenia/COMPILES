% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21 k22 k23 k24 k25 k26 k27 k28 k29 k30 k31 k32 k33 k34 k35
syms X2 X3 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13 X14 X15 X16 X17 X18 X19 X20 X21

% ODEs
ode2  = k2*X3 + k6*X5 - k1*X2 + k8*X6 - k7*X2;                         % X2:  Unbound Insulin Receptor
ode3  = k1*X2 - k2*X3 - k5*X3;                                         % X3:  Unphosphorylated once bound receptor
ode4  = k3*X5 - k4*X4 + k10*X7 - k9*X4;                                % X4:  Phosphorylated twice bound receptor
ode5  = k5*X3 + k4*X4 - k3*X5 - k6*X5 + k12*X8 - k11*X5;               % X5:  Phosphorylated once bound receptor
ode6  = k13 - k14*X6 + k15*X7 + k16*X8 + k7*X2 - k8*X6;                % X6:  Unbound unphosphorylated intracellular receptor
ode7  = k9*X4 - k10*X7 - k15*X7;                                       % X7:  Phosphorylated twice bound intracellular receptor
ode8  = k11*X5 - k12*X8 - k16*X8;                                      % X8:  Phosphorylated once bound intracellular receptor
ode9  = k19*X10 - k17*X9*X4 - k18*X9*X5;                               % X9:  Unphosphorylated IRS1
ode10 = k17*X9*X4 + k18*X9*X5 + k21*X12 - k19*X10 - k20*X10*X11;       % X10: Phosphorylated IRS1
ode11 = k21*X12 - k20*X10*X11;                                         % X11: PI3 Kinase
ode12 = k20*X10*X11 - k21*X12;                                         % X12: IRS1- PI3 Kinase CompleX
ode13 = k22*X12*X14 + k24*X15 - k23*X13 - k25*X13;                     % X13: PI(3,4,5)P3
ode14 = k23*X13 - k22*X12*X14;                                         % X14: PI(4,5)P2
ode15 = k25*X13 - k24*X15;                                             % X15: PI(3,4)P2
ode16 = k27*X17 - k26*X13*X16;                                         % X16: Unactivated Akt
ode17 = k26*X13*X16 - k27*X17;                                         % X17: Activated Akt
ode18 = k29*X19 - k28*X13*X18;                                         % X18: Unactivated PKC
ode19 = k28*X13*X18 - k29*X19;                                         % X19: Activated PKC
ode20 = k31*X21 - k30*X20 - k32*X17*X20 - k33*X19*X20 + k34 - k35*X20; % X20: Intracellular GLUT4
ode21 = k30*X20 + k32*X17*X20 + k33*X19*X20 - k31*X21;                 % X21: Cell surface GLUT4

% Solution
X2  = (k8*k13*(k2 + k5)*(k4*k6*k10*k12 + k4*k6*k10*k16 + k4*k6*k12*k15 + k3*k9*k12*k15 + k4*k6*k15*k16 + k4*k10*k11*k16 + k6*k9*k12*k15 + k3*k9*k15*k16 + k4*k11*k15*k16 + k6*k9*k15*k16 + k9*k11*k15*k16))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X3  = (k1*k8*k13*(k4*k6*k10*k12 + k4*k6*k10*k16 + k4*k6*k12*k15 + k3*k9*k12*k15 + k4*k6*k15*k16 + k4*k10*k11*k16 + k6*k9*k12*k15 + k3*k9*k15*k16 + k4*k11*k15*k16 + k6*k9*k15*k16 + k9*k11*k15*k16))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X4  = (k1*k3*k5*k8*k13*(k10 + k15)*(k12 + k16))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X5  = (k1*k5*k8*k13*(k12 + k16)*(k4*k10 + k4*k15 + k9*k15))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X6  = k13/k14;
X7  = (k1*k3*k5*k8*k9*k13*(k12 + k16))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X8  = (k1*k5*k8*k11*k13*(k4*k10 + k4*k15 + k9*k15))/(k14*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16));
X9  = (X19*k14*k19*k21*k23*k29*(k2*k4*k6*k7*k10*k12 + k4*k5*k6*k7*k10*k12 + k1*k3*k5*k9*k12*k15 + k2*k4*k6*k7*k10*k16 + k2*k4*k6*k7*k12*k15 + k1*k4*k5*k10*k11*k16 + k2*k3*k7*k9*k12*k15 + k4*k5*k6*k7*k10*k16 + k1*k3*k5*k9*k15*k16 + k4*k5*k6*k7*k12*k15 + k2*k4*k6*k7*k15*k16 + k2*k4*k7*k10*k11*k16 + k2*k6*k7*k9*k12*k15 + k3*k5*k7*k9*k12*k15 + k1*k4*k5*k11*k15*k16 + k2*k3*k7*k9*k15*k16 + k4*k5*k6*k7*k15*k16 + k4*k5*k7*k10*k11*k16 + k5*k6*k7*k9*k12*k15 + k2*k4*k7*k11*k15*k16 + k2*k6*k7*k9*k15*k16 + k3*k5*k7*k9*k15*k16 + k1*k5*k9*k11*k15*k16 + k4*k5*k7*k11*k15*k16 + k5*k6*k7*k9*k15*k16 + k2*k7*k9*k11*k15*k16 + k5*k7*k9*k11*k15*k16))/(X11*X14*X18*k1*k5*k8*k13*k20*k22*k28*(k12 + k16)*(k3*k10*k17 + k4*k10*k18 + k3*k15*k17 + k4*k15*k18 + k9*k15*k18));
X10 = (X19*k21*k23*k29)/(X11*X14*X18*k20*k22*k28);
X12 = (X19*k23*k29)/(X14*X18*k22*k28);
X13 = (X19*k29)/(X18*k28);
X15 = (X19*k25*k29)/(X18*k24*k28);
X16 = (X17*X18*k27*k28)/(X19*k26*k29);
X20 = k34/k35;
X21 = (k34*(k30 + X17*k32 + X19*k33))/(k31*k35);

% Check
check2  = simplify(subs(ode2))
check3  = simplify(subs(ode3))
check4  = simplify(subs(ode4))
check5  = simplify(subs(ode5))
check6  = simplify(subs(ode6))
check7  = simplify(subs(ode7))
check8  = simplify(subs(ode8))
check9  = simplify(subs(ode9))
check10 = simplify(subs(ode10))
check11 = simplify(subs(ode11))
check12 = simplify(subs(ode12))
check13 = simplify(subs(ode13))
check14 = simplify(subs(ode14))
check15 = simplify(subs(ode15))
check16 = simplify(subs(ode16))
check17 = simplify(subs(ode17))
check18 = simplify(subs(ode18))
check19 = simplify(subs(ode19))
check20 = simplify(subs(ode20))
check21 = simplify(subs(ode21))